
from flask import Blueprint, request, jsonify, session, redirect, url_for 
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token,unset_jwt_cookies,get_jwt_identity
from functools import wraps
from ..models import db, User

auth_bp = Blueprint('auth', __name__)


def seller_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        current_user = get_jwt_identity()
        user = User.query.get(current_user)
        if not user.is_seller:
            return jsonify({'message': 'You dont have access for this page'}), 403
        return fn(*args, **kwargs)
    return wrapper
@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    is_seller = bool(data.get('is_seller'))

    if not username or not password or not email:
        return jsonify({'message': 'Username ,email and password are required'}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({'message': 'Email already exists'}), 409

    hashed_password = generate_password_hash(password)

    new_user = User(username=username, email=email, password=hashed_password, is_seller=is_seller)

    print(new_user)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'User registered successfully'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    password = data.get('password')
    email = data.get('email')

    if not password or not email:
        return jsonify({'message': 'email and password are required'}), 400

    user = User.query.filter_by(email=email).first()

    if not user or not check_password_hash(user.password, password):
        return jsonify({'message': 'Invalid email or password'}), 401

    access_token = create_access_token(identity=user.id)

    return jsonify({'access_token': access_token,'username': user.username, 'is_seller':user.is_seller}), 200

@auth_bp.route('/logout', methods=['GET'])
def logout():
    response = jsonify({'message': 'Logout successful'})
    unset_jwt_cookies(response)
    
    return response, 200
# @auth_bp.route("/protected",methods=["GET"])
# @jwt_required
# def protected():
#     # Access the identity of the current user with get_jwt_identity
#     current_user = get_jwt
#     return jsonify(current_user), 200
    # @auth_bp.before_app_request
# def before_request():
#     """ Sets up the current user for every request by looking in the JWT token"""