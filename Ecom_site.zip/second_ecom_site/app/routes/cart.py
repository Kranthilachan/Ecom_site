
from flask import jsonify, Blueprint, request
from ..models import db, Cart, Product, User
from flask_jwt_extended import jwt_required, get_jwt_identity

cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/cart', methods=['GET'])
@jwt_required()
def get_cart():
    user_id = get_jwt_identity()
    cart_items = Cart.query.filter_by(user_id=user_id).all()

    cart_data = []

    for cart_item in cart_items:
        product = Product.query.get(cart_item.product_id)

        if product:
            item_details = {
                'product_id': cart_item.product_id,
                'quantity': cart_item.quantity,
                'product_name': product.name,
                'product_price': product.price,
                'product_description': product.description,
                'image': product.image
            }
            cart_data.append(item_details)

    return jsonify({'cart': cart_data}), 200


@cart_bp.route('/cart/add', methods=['POST'])
@jwt_required()
def add_to_cart():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    data = request.json
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1) 

    product = Product.query.get(product_id)
    if not product:
        return jsonify({'message': 'Product not found'}), 404

    # Check if the product is already in the cart
    cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
    if cart_item:
        # If the product is already in the cart, update the quantity
        cart_item.quantity = quantity
    else:
        # If the product is not in the cart, add a new entry
        cart_item = Cart(user_id=user_id, product_id=product_id, quantity=quantity)

    db.session.add(cart_item)
    db.session.commit()

    return jsonify({'message': 'Product added to cart successfully'}), 201


@cart_bp.route('/cart/delete', methods=['DELETE'])
@jwt_required()
def delete_from_cart():
    user_id = get_jwt_identity()

    data = request.json
    product_id = data.get('product_id')

    cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
    if not cart_item:
        return jsonify({'message': 'Product not found in cart'}), 404

    db.session.delete(cart_item)
    db.session.commit()

    return jsonify({'message': 'Product deleted from cart successfully'}), 200

