
import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..')))

from app.models import db,Product,User
from flask import Blueprint, request, jsonify,session 
from flask_jwt_extended import jwt_required, get_jwt_identity
from base64 import b64encode
from .auth import seller_required

products_bp = Blueprint('products', __name__)

# Function to check if the file extension is allowed
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@products_bp.route('/products', methods=['GET'])
@jwt_required() 
def get_products():
    product_type = request.args.get('type')

    if product_type:
        products = Product.query.filter_by(type=product_type).all()
    else:
        products = Product.query.all()

    result = [{'id': product.id,
                'name': product.name, 
                'price': product.price, 
                'description': product.description, 
                'image':product.image, 
                'type':product.type} for product in products]
    return jsonify(result)


# Fetch product by ID
@products_bp.route('/products/<int:product_id>', methods=['GET'])
@jwt_required() 
def get_product(product_id):
    # if 'user_id' not in session:
    #     return jsonify({'message': 'Unauthorized'}), 401
    product = Product.query.get(product_id)
    if not product:
        return jsonify({'message': 'Product not found'}), 404

    product_data = {
        'id': product.id,
        'name': product.name,
        'description': product.description,
        'price': product.price,
        'image':product.image, 
        'type':product.type
    }

    return jsonify(product_data), 200


# @products_bp.route('/products', methods=['POST'])
# def create_product():
#     if 'user_id' not in session:
#         return jsonify({'message': 'Unauthorized'}), 401
#     data = request.json
#     name = data.get('name')
#     price = data.get('price')
#     description = data.get('description')

#     if not name or not price:
#         return jsonify({'message': 'Name and price are required'}), 400

#     new_product = Product(name=name, price=price, description=description)
#     db.session.add(new_product)
#     db.session.commit()

#     return jsonify({'message': 'Product created successfully'}), 201

@products_bp.route('/products', methods=['POST'])
@jwt_required()
@seller_required
def create_product():
    # if 'user_id' not in session:
    #     return jsonify({'message': 'Unauthorized'}), 401
    
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user.is_seller:
        return jsonify({'message': 'You dont have access for this page'}), 403

    data = request.form
    name = data.get('name')
    price = data.get('price')
    description = data.get('description')
    image = request.files.get('image')
    type = data.get('type')

    if not name or not price or not image or not type:
        return jsonify({'message': 'Name, price, type, and image are required'}), 400

    if not allowed_file(image.filename):
        return jsonify({'message': 'Invalid image type. Allowed types are: png, jpg, jpeg, gif'}), 400

    image_data = image.read()
    encoded_image = b64encode(image_data).decode('utf-8')

    new_product = Product(name=name, price=price, description=description, image=encoded_image, type=type)
    db.session.add(new_product)
    db.session.commit()

    return jsonify({'message': 'Product created successfully'}), 201

# Update product by ID
# @products_bp.route('/products/<int:product_id>', methods=['PUT'])
# def update_product(product_id):
#     if 'user_id' not in session:
#         return jsonify({'message': 'Unauthorized'}), 401
#     data = request.json
#     product = Product.query.get(product_id)
#     if not product:
#         return jsonify({'message': 'Product not found'}), 404

#     # Update product attributes
#     if 'name' in data:
#         product.name = data['name']
#     if 'description' in data:
#         product.description = data['description']
#     if 'price' in data:
#         product.price = data['price']
#     # Add more attributes as needed

#     db.session.commit()

#     return jsonify({'message': 'Product updated successfully'}), 200

@products_bp.route('/products/<int:product_id>', methods=['PUT'])
@jwt_required()
@seller_required
def update_product(product_id):
    # if 'user_id' not in session:
    #     return jsonify({'message': 'Unauthorized'}), 401
    
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user.is_seller:
        return jsonify({'message': 'You dont have access for this page'}), 403

    data = request.form
    product = Product.query.get(product_id)
    if not product:
        return jsonify({'message': 'Product not found'}), 404

    name = data.get('name', product.name)
    description = data.get('description', product.description)
    price = data.get('price', product.price)
    image = request.files.get('image')
    type = data.get('type',product.type)

    if image:
        if not allowed_file(image.filename):
            return jsonify({'message': 'Invalid image type. Allowed types are: png, jpg, jpeg, gif'}), 400

        image_data = image.read()
        encoded_image = b64encode(image_data).decode('utf-8')
        product.image = encoded_image

    product.name = name
    product.description = description
    product.price = price
    product.type = type

    db.session.commit()

    return jsonify({'message': 'Product updated successfully'}), 200

# Delete product by ID
@products_bp.route('/products/<int:product_id>', methods=['DELETE'])
@jwt_required()
@seller_required
def delete_product(product_id):
    product = Product.query.get(product_id)
    if not product:
        return jsonify({'message': 'Product not found'}), 404

    db.session.delete(product)
    db.session.commit()

    return jsonify({'message': 'Product deleted successfully'}), 200


