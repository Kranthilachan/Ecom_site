import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..')))

import unittest
from flask import json
from app import create_app, db
from app.models import User

class AuthTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()

    def register_user(self, username, password, email, is_seller):
        return self.client.post('/register', json={'username': username, 'password': password, 'email': email, 'is_seller': is_seller})

    def login_user(self, email, password):
        return self.client.post('/login', json={'email': email, 'password': password})

    def logout_user(self):
        return self.client.get('/logout')

    def test_register_login_logout(self):
        register_response = self.register_user('test_user22', 'password123', 'test222@example.com', True)
        self.assertEqual(register_response.status_code, 201)

        duplicate_register_response = self.register_user('test_user22', 'password123', 'test222@example.com', True)
        self.assertEqual(duplicate_register_response.status_code, 409)

        login_response = self.login_user('test222@example.com', 'password123')
        self.assertEqual(login_response.status_code, 200)
        access_token = json.loads(login_response.data)['access_token']
        self.assertIsNotNone(access_token)

        logout_response = self.logout_user()
        self.assertEqual(logout_response.status_code, 200)


    def test_register_user_success(self):
        # Provide all required data correctly
        register_response = self.register_user('test_user', 'password123', 'test@example.com', False)
        self.assertEqual(register_response.status_code, 201)
        self.assertEqual(register_response.json['message'], 'User registered successfully')

    def test_register_user_duplicate_email(self):
        # Attempt to register with an email that already exists
        existing_user = User(username='existing_user', email='test@example.com', password='hashed_password', is_seller=False)
        with self.app.app_context():
            db.session.add(existing_user)
            db.session.commit()
        register_response = self.register_user('test_user', 'password123', 'test@example.com', False)
        self.assertEqual(register_response.status_code, 409)
        self.assertEqual(register_response.json['message'], 'Email already exists')

    def test_register_user_missing_data(self):
        # Missing required data (username, password, email)
        register_response = self.register_user('', 'password123', 'test@example.com', False)
        self.assertEqual(register_response.status_code, 400)
        self.assertEqual(register_response.json['message'], 'Username ,email and password are required')

    def test_register_user_with_seller_status(self):
        # Provide all required data including is_seller
        register_response = self.register_user('test_user', 'password123', 'test@example.com', True)
        self.assertEqual(register_response.status_code, 201)
        self.assertEqual(register_response.json['message'], 'User registered successfully')

    def test_register_user_with_invalid_data(self):
        # Provide invalid data (empty JSON)
        register_response = self.client.post('/register', json={})
        self.assertEqual(register_response.status_code, 400)
        self.assertEqual(register_response.json['message'], 'Username ,email and password are required')   

if __name__ == '__main__':
    unittest.main()
