import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

# test_cart.py

import unittest
from unittest.mock import patch

from flask import jsonify

from app import create_app
from app.routes.cart import cart_bp

class TestCart(unittest.TestCase):

    def setUp(self):
        self.app = create_app().test_client()
        self.app_context = self.app.application.app_context()
        self.app_context.push()

    def tearDown(self):
        self.app_context.pop()

    @patch('app.routes.cart.get_jwt_identity')
    @patch('app.routes.cart.Cart')
    def test_get_cart(self, mock_cart, mock_jwt):
        mock_jwt.return_value = 1
        mock_cart.query.filter_by.return_value.all.return_value = [
            {'product_id': 1, 'quantity': 2}
        ]
        
        response = self.app.get('/cart')
        
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {'cart': [
            {'product_id': 1, 'quantity': 2} 
        ]})

    @patch('app.routes.cart.get_jwt_identity')
    @patch('app.routes.cart.Cart')
    def test_add_to_cart(self, mock_cart, mock_jwt):
        mock_jwt.return_value = 1
        mock_cart.query.filter_by.return_value.first.return_value = None
        
        data = {'product_id': 1, 'quantity': 2}
        response = self.app.post('/cart/add', json=data)

        self.assertEqual(response.status_code, 401)

    @patch('app.routes.cart.get_jwt_identity')
    @patch('app.routes.cart.Cart')
    def test_delete_from_cart(self, mock_cart, mock_jwt):
        mock_jwt.return_value = 1
        mock_cart.query.filter_by.return_value.first.return_value = True
        
        data = {'product_id': 1}
        response = self.app.delete('/cart/delete', json=data)

        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
